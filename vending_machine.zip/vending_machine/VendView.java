package cp213;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

@SuppressWarnings("serial")
public class VendView extends JFrame implements ActionListener {
	private JButton oneJButton, twoJButton, threeJButton, fourJButton, fiveJButton, sixJButton, sevenJButton,
			eightJButton, nineJButton, zeroJButton, asteriskJButton, poundJButton, aJButton, bJButton, cJButton,
			dJButton, finishJButton, insertMoneyJButton;

	private JButton Cent1JButton, Cent5JButton, Cent10JButton, Cent25JButton, dolla1JButton, dolla2JButton,
			dolla5JButton, dolla10JButton;

	private JLabel a1JLabel, a2JLabel, a3JLabel, b1JLabel, b2JLabel, b3JLabel, c1JLabel, c2JLabel, c3JLabel, d1JLabel,
			d2JLabel, d3JLabel;
	private JPanel windowJPanel, selectionJPanel, moneyJPanel;
	private JTextField displayJTextField, insertMoney, changeDue;
	private static double availableBalance = 0.00;
	private int count = 0;
	private String all = "";

	// SELECTION
	private String select;
	private boolean selectTest = false;
	private List<String> purchase = new ArrayList<String>();
	private final VendModel vendmodel;

	// no-argument constructor
	public VendView(VendModel avendmodel) {
		vendmodel = avendmodel;
		createUserInterface();
	}

	// create and position GUI components
	private void createUserInterface() {
		// get content pane and set layout to null
		Container contentPane = getContentPane();
		contentPane.setLayout(null);

		// set up windowJPanel
		windowJPanel = new JPanel();
		windowJPanel.setBounds(10, 10, 190, 380);
		windowJPanel.setBorder(new LineBorder(Color.BLACK));
		windowJPanel.setLayout(null);
		contentPane.add(windowJPanel);

		// set up a1JLabel
		a1JLabel = new JLabel();
		a1JLabel.setText("A1");
		a1JLabel.setBounds(10, 60, 50, 20);
		a1JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(a1JLabel);

		// set up a2JLabel
		a2JLabel = new JLabel();
		a2JLabel.setText("A2");
		a2JLabel.setBounds(70, 60, 50, 20);
		a2JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(a2JLabel);

		// set up a3JLabel
		a3JLabel = new JLabel();
		a3JLabel.setText("A3");
		a3JLabel.setBounds(130, 60, 50, 20);
		a3JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(a3JLabel);

		// set up b1JLabel
		b1JLabel = new JLabel();
		b1JLabel.setText("B1");
		b1JLabel.setBounds(10, 140, 50, 20);
		b1JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(b1JLabel);

		// set up b2JLabel
		b2JLabel = new JLabel();
		b2JLabel.setText("B2");
		b2JLabel.setBounds(70, 140, 50, 20);
		b2JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(b2JLabel);

		// set up b3JLabel
		b3JLabel = new JLabel();
		b3JLabel.setText("B3");
		b3JLabel.setBounds(130, 140, 50, 20);
		b3JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(b3JLabel);

		// set up c1JLabel
		c1JLabel = new JLabel();
		c1JLabel.setText("C1");
		c1JLabel.setBounds(10, 220, 50, 20);
		c1JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(c1JLabel);

		// set up c2JLabel
		c2JLabel = new JLabel();
		c2JLabel.setText("C2");
		c2JLabel.setBounds(70, 220, 50, 20);
		c2JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(c2JLabel);

		// set up c3JLabel
		c3JLabel = new JLabel();
		c3JLabel.setText("C3");
		c3JLabel.setBounds(130, 220, 50, 20);
		c3JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(c3JLabel);

		// set up d1JLabel
		d1JLabel = new JLabel();
		d1JLabel.setText("D1");
		d1JLabel.setBounds(10, 300, 50, 20);
		d1JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(d1JLabel);

		// set up d2JLabel
		d2JLabel = new JLabel();
		d2JLabel.setText("D2");
		d2JLabel.setBounds(70, 300, 50, 20);
		d2JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(d2JLabel);

		// set up d3JLabel
		d3JLabel = new JLabel();
		d3JLabel.setText("D3");
		d3JLabel.setBounds(130, 300, 50, 20);
		d3JLabel.setHorizontalAlignment(JLabel.CENTER);
		windowJPanel.add(d3JLabel);

		// set up finishJButton
		finishJButton = new JButton("FINISH");
		finishJButton.addActionListener(this);
		finishJButton.setBounds(10, 400, 190, 30);
		contentPane.add(finishJButton);

		// set up displayJTextField
		displayJTextField = new JTextField();
		displayJTextField.setText("");
		displayJTextField.setBounds(210, 10, 170, 30);
		displayJTextField.setEditable(false);
		displayJTextField.setHorizontalAlignment(JLabel.CENTER);
		contentPane.add(displayJTextField);

		// set up selectionJPanel
		selectionJPanel = new JPanel();
		selectionJPanel.setBounds(210, 50, 170, 332);
		selectionJPanel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED), "Selection/Payement"));
		selectionJPanel.setLayout(null);
		contentPane.add(selectionJPanel);

		// set up aJButton
		aJButton = new JButton("A");
		aJButton.addActionListener(this);
		aJButton.setBounds(40, 20, 42, 42);
		selectionJPanel.add(aJButton);

		// set up bJButton
		bJButton = new JButton("B");
		bJButton.addActionListener(this);
		bJButton.setBounds(90, 20, 42, 42);
		selectionJPanel.add(bJButton);

		// set up cJButton
		cJButton = new JButton("C");
		cJButton.addActionListener(this);
		cJButton.setBounds(40, 72, 42, 42);
		selectionJPanel.add(cJButton);

		// set up dJButton
		dJButton = new JButton("D");
		dJButton.addActionListener(this);
		dJButton.setBounds(90, 72, 42, 42);
		selectionJPanel.add(dJButton);

		// set up oneJButton
		oneJButton = new JButton("1");
		oneJButton.addActionListener(this);
		oneJButton.setBounds(12, 124, 42, 42);
		selectionJPanel.add(oneJButton);

		// set up twoJButton
		twoJButton = new JButton("2");
		twoJButton.addActionListener(this);
		twoJButton.setBounds(64, 124, 42, 42);
		selectionJPanel.add(twoJButton);

		// set up threeJButton
		threeJButton = new JButton("3");
		threeJButton.addActionListener(this);
		threeJButton.setBounds(116, 124, 42, 42);
		selectionJPanel.add(threeJButton);

		// set up fourJButton
		fourJButton = new JButton("4");
		fourJButton.addActionListener(this);
		fourJButton.setBounds(12, 176, 42, 42);
		selectionJPanel.add(fourJButton);

		// set up fiveJButton
		fiveJButton = new JButton("5");
		fiveJButton.addActionListener(this);
		fiveJButton.setBounds(64, 176, 42, 42);
		selectionJPanel.add(fiveJButton);

		// set up sixJButton
		sixJButton = new JButton("6");
		sixJButton.addActionListener(this);
		sixJButton.setBounds(116, 176, 42, 42);
		selectionJPanel.add(sixJButton);

		// set up sevenJButton
		sevenJButton = new JButton("7");
		sevenJButton.addActionListener(this);
		sevenJButton.setBounds(12, 228, 42, 42);
		selectionJPanel.add(sevenJButton);

		// set up eightJButton
		eightJButton = new JButton("8");
		eightJButton.addActionListener(this);
		eightJButton.setBounds(64, 228, 42, 42);
		selectionJPanel.add(eightJButton);

		// set up nineJButton
		nineJButton = new JButton("9");
		nineJButton.addActionListener(this);
		nineJButton.setBounds(116, 228, 42, 42);
		selectionJPanel.add(nineJButton);

		// set up zeroJButton
		zeroJButton = new JButton("0");
		zeroJButton.addActionListener(this);
		zeroJButton.setBounds(64, 280, 42, 42);
		selectionJPanel.add(zeroJButton);

		// set up asteriskJButton
		asteriskJButton = new JButton("*");
		asteriskJButton.addActionListener(this);
		asteriskJButton.setBounds(12, 280, 42, 42);
		selectionJPanel.add(asteriskJButton);

		// set up poundJButton
		poundJButton = new JButton("#");
		poundJButton.addActionListener(this);
		poundJButton.setBounds(116, 280, 42, 42);
		selectionJPanel.add(poundJButton);

		// set up moneyJPanel
		moneyJPanel = new JPanel();
		moneyJPanel.setBounds(400, 50, 155, 235);
		moneyJPanel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED), "Payement"));
		moneyJPanel.setLayout(null);
		contentPane.add(moneyJPanel);

		// set up Cent1JButton
		Cent1JButton = new JButton("1�");
		Cent1JButton.addActionListener(this);
		Cent1JButton.setBounds(10, 20, 55, 42);
		moneyJPanel.add(Cent1JButton);

		// set up 5CentJButton
		Cent5JButton = new JButton("5�");
		Cent5JButton.addActionListener(this);
		Cent5JButton.setBounds(10, 72, 55, 42);
		moneyJPanel.add(Cent5JButton);

		// set up 5CentJButton
		Cent10JButton = new JButton("10�");
		Cent10JButton.addActionListener(this);
		Cent10JButton.setBounds(10, 124, 55, 42);
		moneyJPanel.add(Cent10JButton);

		// set up 5CentJButton
		Cent25JButton = new JButton("25�");
		Cent25JButton.addActionListener(this);
		Cent25JButton.setBounds(10, 176, 55, 42);
		moneyJPanel.add(Cent25JButton);

		// set up dolla1JButton
		dolla1JButton = new JButton("$1");
		dolla1JButton.addActionListener(this);
		dolla1JButton.setBounds(85, 20, 55, 42);
		moneyJPanel.add(dolla1JButton);

		// set up dolla2JButton
		dolla2JButton = new JButton("$2");
		dolla2JButton.addActionListener(this);
		dolla2JButton.setBounds(85, 72, 55, 42);
		moneyJPanel.add(dolla2JButton);

		// set up dolla5JButton
		dolla5JButton = new JButton("$5");
		dolla5JButton.addActionListener(this);
		dolla5JButton.setBounds(85, 124, 55, 42);
		moneyJPanel.add(dolla5JButton);

		// set up dolla10JButton
		dolla10JButton = new JButton("$10");
		dolla10JButton.addActionListener(this);
		dolla10JButton.setBounds(85, 176, 55, 42);
		moneyJPanel.add(dolla10JButton);

		// set up insertMoneyJTextField
		insertMoney = new JTextField();
		insertMoney.setText("");
		insertMoney.setBounds(400, 290, 155, 30);
		insertMoney.setEditable(true);
		insertMoney.setHorizontalAlignment(JLabel.CENTER);
		contentPane.add(insertMoney);
		insertMoney.addActionListener(this);

		// set up changeDueJTextField
		changeDue = new JTextField();
		changeDue.setText("");
		changeDue.setBounds(400, 400, 155, 30);
		changeDue.setEditable(true);
		changeDue.setHorizontalAlignment(JLabel.CENTER);
		contentPane.add(changeDue);
		changeDue.addActionListener(this);

		// set up insertMoneyJButton
		insertMoneyJButton = new JButton("insert Money");
		insertMoneyJButton.addActionListener(this);
		insertMoneyJButton.setBounds(400, 330, 120, 60);
		contentPane.add(insertMoneyJButton);

		// set properties of application's window
		setTitle("VendView"); // set title bar text
		setSize(900, 900); // set window size
		setVisible(true); // display window

	} // end method createUserInterface

	// main method
	public static void main(String[] args) {
		VendModel vendModel = new VendModel();
		VendView application = new VendView(vendModel);
		application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	} // end method main

	// public VendView(String title) {
	// this.setTitle(title);
	// }

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == insertMoneyJButton) {
			String mon = insertMoney.getText();
			try {
				availableBalance = Double.parseDouble(mon);

			} catch (NumberFormatException e1) {
				JOptionPane.showMessageDialog(null, "Enter a valid currencery value. (eg #.##)");
				insertMoney.setText("");
			}
			if (availableBalance - vendmodel.cost > 0) {
				double changer = (vendmodel.currency(availableBalance - vendmodel.cost));
				changeDue.setText(String.format("%.2f", changer));
			}
			if (availableBalance - vendmodel.cost < 0) {
				double tp = vendmodel.cost - availableBalance;
				double number = tp;
				DecimalFormat decimalFormat = new DecimalFormat("#.00");
				String numAsStr = decimalFormat.format(number);
				JOptionPane.showMessageDialog(null, "Please insert " + numAsStr + " or more to receive item(s).");
			}

		}
		if (e.getSource() == aJButton) {
			select = "A";
			selectTest = true;
		}
		if (e.getSource() == bJButton) {
			select = "B";
			selectTest = true;
		}
		if (e.getSource() == cJButton) {
			select = "C";
			selectTest = true;
		}
		if (e.getSource() == dJButton) {
			select = "D";
			selectTest = true;
		}
		if (e.getSource() == oneJButton) {
			if (selectTest == true) {
				select = select + "1";
				purchase.add(select);
				String x = purchase.get(count);
				boolean xx = vendmodel.sget(x);
				if (xx == true) {
					Item s = new Item();
					s = vendmodel.getCart().get(count);
					all = all + s.selectionID + " ";
					displayJTextField.setText(all);
				} else {
					JOptionPane.showMessageDialog(null, "Sorry this item is out of stock");
				}
				count++;
				select = "";
				selectTest = false;
			}
		}
		if (e.getSource() == twoJButton) {
			if (selectTest == true) {
				select = select + "2";
				purchase.add(select);
				String x = purchase.get(count);
				boolean xx = vendmodel.sget(x);
				if (xx == true) {
					Item s = new Item();
					s = vendmodel.getCart().get(count);
					all = all + s.selectionID + " ";
					displayJTextField.setText(all);
				} else {
					JOptionPane.showMessageDialog(null, "Sorry this item is out of stock");
				}
				count++;
				select = "";
				selectTest = false;
			}
		}

		if (e.getSource() == threeJButton) {
			if (selectTest == true) {
				select = select + "3";
				purchase.add(select);
				String x = purchase.get(count);
				boolean xx = vendmodel.sget(x);
				if (xx == true) {
					Item s = new Item();
					s = vendmodel.getCart().get(count);
					all = all + s.selectionID + " ";
					displayJTextField.setText(all);
				} else {
					JOptionPane.showMessageDialog(null, "Sorry this item is out of stock");
				}
				count++;
				select = "";
				selectTest = false;
			}
		}

		if (e.getSource() == fourJButton) {
			if (selectTest == true) {
				select = select + "4";
				purchase.add(select);
				String x = purchase.get(count);
				boolean xx = vendmodel.sget(x);
				if (xx == true) {
					Item s = new Item();
					s = vendmodel.getCart().get(count);
					all = all + s.selectionID + " ";
					displayJTextField.setText(all);
				} else {
					JOptionPane.showMessageDialog(null, "Sorry this item is out of stock");
				}
				count++;
				select = "";
				selectTest = false;
			}
		}

		if (e.getSource() == fiveJButton) {
			if (selectTest == true) {
				select = select + "5";
				purchase.add(select);
				String x = purchase.get(count);
				boolean xx = vendmodel.sget(x);
				if (xx == true) {
					Item s = new Item();
					s = vendmodel.getCart().get(count);
					all = all + s.selectionID + " ";
					displayJTextField.setText(all);
				} else {
					JOptionPane.showMessageDialog(null, "Sorry this item is out of stock");
				}
				count++;
				select = "";
				selectTest = false;
			}
		}

		if (e.getSource() == sixJButton) {
			if (selectTest == true) {
				select = select + "6";
				purchase.add(select);
				String x = purchase.get(count);
				boolean xx = vendmodel.sget(x);
				if (xx == true) {
					Item s = new Item();
					s = vendmodel.getCart().get(count);
					all = all + s.selectionID + " ";
					displayJTextField.setText(all);
				} else {
					JOptionPane.showMessageDialog(null, "Sorry this item is out of stock");
				}
				count++;
				select = "";
				selectTest = false;
			}
		}

		if (e.getSource() == sevenJButton) {
			if (selectTest == true) {
				select = select + "7";
				purchase.add(select);
				String x = purchase.get(count);
				boolean xx = vendmodel.sget(x);
				if (xx == true) {
					Item s = new Item();
					s = vendmodel.getCart().get(count);
					all = all + s.selectionID + " ";
					displayJTextField.setText(all);
				} else {
					JOptionPane.showMessageDialog(null, "Sorry this item is out of stock");
				}
				count++;
				select = "";
				selectTest = false;
			}
		}

		if (e.getSource() == eightJButton) {
			if (selectTest == true) {
				select = select + "8";
				purchase.add(select);
				String x = purchase.get(count);
				boolean xx = vendmodel.sget(x);
				if (xx == true) {
					Item s = new Item();
					s = vendmodel.getCart().get(count);
					all = all + s.selectionID + " ";
					displayJTextField.setText(all);
				} else {
					JOptionPane.showMessageDialog(null, "Sorry this item is out of stock");
				}
				count++;
				select = "";
				selectTest = false;
			}
		}

		if (e.getSource() == nineJButton) {
			if (selectTest == true) {
				select = select + "9";
				purchase.add(select);
				String x = purchase.get(count);
				boolean xx = vendmodel.sget(x);
				if (xx == true) {
					Item s = new Item();
					s = vendmodel.getCart().get(count);
					all = all + s.selectionID + " ";
					displayJTextField.setText(all);
				} else {
					JOptionPane.showMessageDialog(null, "Sorry this item is out of stock");
				}
				count++;
				select = "";
				selectTest = false;
			}
		}

		if (e.getSource() == zeroJButton) {
			if (selectTest == true) {
				select = select + "0";
				purchase.add(select);
				String x = purchase.get(count);
				boolean xx = vendmodel.sget(x);
				if (xx == true) {
					Item s = new Item();
					s = vendmodel.getCart().get(count);
					all = all + s.selectionID + " ";
					displayJTextField.setText(all);
				} else {
					JOptionPane.showMessageDialog(null, "Sorry this item is out of stock");
				}
				count++;
				select = "";
				selectTest = false;
			}
		}

		if (e.getSource() == Cent1JButton) {
			availableBalance = availableBalance + 0.01;
			insertMoney.setText(String.format("%.2f", availableBalance));
		}
		if (e.getSource() == Cent5JButton) {
			availableBalance = availableBalance + 0.05;
			insertMoney.setText(String.format("%.2f", availableBalance));
		}
		if (e.getSource() == Cent10JButton) {
			availableBalance = availableBalance + 0.10;
			insertMoney.setText(String.format("%.2f", availableBalance));
		}
		if (e.getSource() == Cent25JButton) {
			availableBalance = availableBalance + 0.25;
			insertMoney.setText(String.format("%.2f", availableBalance));
		}
		if (e.getSource() == dolla1JButton) {
			availableBalance = availableBalance + 1.00;
			insertMoney.setText(String.format("%.2f", availableBalance));
		}
		if (e.getSource() == dolla2JButton) {
			availableBalance = availableBalance + 2.00;
			insertMoney.setText(String.format("%.2f", availableBalance));
		}
		if (e.getSource() == dolla5JButton) {
			availableBalance = availableBalance + 5.00;
			insertMoney.setText(String.format("%.2f", availableBalance));
		}
		if (e.getSource() == dolla10JButton) {
			availableBalance = availableBalance + 10.00;
			insertMoney.setText(String.format("%.2f", availableBalance));
		}

		if (e.getSource() == finishJButton) {
			aJButton.setEnabled(false);
			bJButton.setEnabled(false);
			cJButton.setEnabled(false);
			dJButton.setEnabled(false);
			oneJButton.setEnabled(false);
			twoJButton.setEnabled(false);
			threeJButton.setEnabled(false);
			fourJButton.setEnabled(false);
			fiveJButton.setEnabled(false);
			sixJButton.setEnabled(false);
			sevenJButton.setEnabled(false);
			eightJButton.setEnabled(false);
			nineJButton.setEnabled(false);
			zeroJButton.setEnabled(false);
			asteriskJButton.setEnabled(false);
			poundJButton.setEnabled(false);
		}
	}
}
