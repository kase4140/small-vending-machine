package cp213;

import java.util.ArrayList;
import java.util.List;

public class VendModel {
	public double cost = 0.00;
	static List<Item> cart = new ArrayList<>();
	List<Item> allItems = new ArrayList<>();
	// bills
	final double ten = 10.00;
	final double five = 5.00;
	final double toonie = 2.00;
	final double loonie = 1.00;
	final double quarter = 0.25;
	final double dime = 0.10;
	final double nickel = 0.05;
	final double penny = 0.01;

	public List<Item> vendItems() {

		Item chips1 = new Item();
		chips1.addItem("lays", 8, "A1", 3.0);
		Item chips2 = new Item();
		chips2.addItem("ruffles", 7, "A2", 2.99);
		Item chips3 = new Item();
		chips3.addItem("Doritios", 10, "A3", 3.35);
		allItems.add(chips1);
		allItems.add(chips2);
		allItems.add(chips3);

		Item choco1 = new Item();
		choco1.addItem("smarties", 10, "B1", 2.10);
		Item choco2 = new Item();
		choco2.addItem("mars", 10, "B2", 1.15);
		Item choco3 = new Item();
		choco3.addItem("kit kat", 1, "B3", 2.33);
		allItems.add(choco1);
		allItems.add(choco2);
		allItems.add(choco3);

		Item drink1 = new Item();
		drink1.addItem("Coke", 5, "C1", 1.20);
		Item drink2 = new Item();
		drink2.addItem("Pepsi", 10, "C2", 0.86);
		Item drink3 = new Item();
		drink3.addItem("Sprite", 16, "C3", 0.95);
		allItems.add(drink1);
		allItems.add(drink2);
		allItems.add(drink3);

		Item gum1 = new Item();
		gum1.addItem("Juicy Fruit", 5, "D1", .89);
		Item gum2 = new Item();
		gum2.addItem("dentyne", 4, "D2", .63);
		Item gum3 = new Item();
		gum3.addItem("Extra", 16, "D3", 1.00);
		allItems.add(gum1);
		allItems.add(gum2);
		allItems.add(gum3);

		return allItems;
	}

	private boolean checkStock(int x) {
		boolean value = false;
		if (vendItems().get(x).stockLevel > 0) {
			value = true;
		}
		return value;
	}

	public void purchase(int x) {
		if (checkStock(x) == true) {
			cost = cost + vendItems().get(x).price;
			cart.add(vendItems().get(x));
			vendItems().get(x).stockLevel--;
		}
	}

	public List<Item> getCart() {
		return cart;
	}

	public double cartCost() {
		return cost;
	}

	public boolean sget(String id) {
		boolean possible = false;
		int x = vendItems().size();
		for (int i = 0; i < x; i++) {
			if (id.equals(vendItems().get(i).selectionID)) {
				int count = vendItems().get(i).stockLevel;
				purchase(i);
				if (count > vendItems().get(i).stockLevel) {
					possible = true;
				}
				id = "";
			}
		}
		return possible;
	}

	public double currency(double givenMoney) {
		int valueIntegral = (int) givenMoney;
		int valueFractional = (int) Math.round(100 * givenMoney - 100 * valueIntegral);
		int tenb = valueIntegral / 10;
		int fiveb = (valueIntegral % 10) / 5;
		int twob = ((valueIntegral % 10) % 5) / 2;
		int oneb = (((valueIntegral % 10) % 5) % 2) / 1;

		int quarterb = valueFractional / 25;
		int dimeb = (valueFractional % 25) / 10;
		int nickelb = ((valueFractional % 25) % 10) / 5;
		int pennyb = (((valueFractional % 25) % 10) % 5) / 1;
		double finalnum = (tenb * ten) + (fiveb * five) + (twob * toonie) + (oneb * loonie) + (quarterb * quarter)
				+ (dimeb * dime) + (nickelb * nickel) + (pennyb * penny);
		return finalnum;
	}

}
