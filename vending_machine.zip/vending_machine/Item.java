package cp213;

public class Item {
	String itemName;
	int stockLevel;
	String selectionID; // Values that need to be stored in the item class
	double price;

	void addItem(String aName, int numberOf, String sID, double aPrice) {

		itemName = aName;
		stockLevel = numberOf; // Method to set values of new instances
		selectionID = sID;
		price = aPrice;
	}

	void stockAdjust(int purchAmount) {
		this.stockLevel = this.stockLevel - purchAmount; // Method to decrement stock level after successful vend
	}

}
